<?php
$dsn='mysql:host=localhost;dbname=blog_admin_db';//dbname and host
$username='root';//username
$password='';//password
?>